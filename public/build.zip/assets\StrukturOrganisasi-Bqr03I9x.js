import{c as e,n as t,t as n}from"./app-DUe1g9sr.js";import{t as r}from"./PublicLayout-BJLeSPr0.js";import{t as i}from"./Breadcrumb-DHSyVB2C.js";e();var a=n(),o=e=>e?e.substring(0,2).toUpperCase():`??`,s=({node:e})=>{let t=e.urutan===`1`,n=e.urutan===`2A`||e.urutan===`2B`,r=t?`inline-flex flex-col items-center bg-white rounded-xl shadow-lg border-2 border-emerald-500 p-6 w-80 relative z-10 transform transition-transform hover:-translate-y-1 hover:shadow-xl`:n?`inline-flex flex-col items-center bg-white rounded-xl shadow-md border border-slate-200 p-5 w-72 relative z-10 transform transition-transform hover:-translate-y-1 hover:border-emerald-300`:`inline-flex flex-col items-center bg-white rounded-lg shadow-sm border border-slate-100 p-4 w-64 relative z-10 transform transition-transform hover:-translate-y-1 hover:border-emerald-200`,i=t?`w-32 h-40 mb-4 rounded-md overflow-hidden border-4 border-emerald-100 shadow-sm relative bg-slate-200 flex items-center justify-center`:n?`w-28 h-36 mb-4 rounded-md overflow-hidden border-2 border-emerald-50 shadow-sm relative bg-slate-200 flex items-center justify-center`:`w-24 h-32 mb-3 rounded-md overflow-hidden border border-slate-100 relative bg-slate-200 flex items-center justify-center`,c=t?`text-xs font-semibold text-white bg-emerald-600 px-3 py-1.5 rounded-lg mt-1 block shadow-sm w-full text-center leading-snug`:n?`text-xs font-medium text-amber-700 bg-amber-100 px-2 py-1.5 rounded-lg mt-1 w-full text-center leading-snug`:`text-[11px] font-medium text-slate-700 bg-slate-100 px-2 py-1 rounded-md w-full text-center leading-snug`;return(0,a.jsxs)(`li`,{children:[(0,a.jsxs)(`div`,{className:r,children:[(0,a.jsx)(`div`,{className:i,children:e.foto?(0,a.jsx)(`img`,{src:e.foto,alt:e.nama,className:`w-full h-full object-cover`}):(0,a.jsx)(`span`,{className:`text-slate-600 font-bold ${t?`text-2xl`:n?`text-xl`:`text-lg`}`,children:o(e.nama)})}),(0,a.jsx)(`h3`,{className:`font-bold text-slate-700 mb-1 leading-tight ${t?`text-md text-slate-800`:n?`text-sm`:`text-xs`}`,children:e.nama}),(0,a.jsx)(`p`,{className:c,children:e.jabatan})]}),e.children&&e.children.length>0&&(0,a.jsx)(`ul`,{children:e.children.map(e=>(0,a.jsx)(s,{node:e},e.id))})]})};function c({organisasi:e,jabatanTree:n,pengaturan:o}){let c=o?.banner_image||`/images/default-banner.jpg`;return(0,a.jsxs)(r,{children:[(0,a.jsx)(t,{title:`Struktur Organisasi | Pascasarjana IAI Persis Bandung`}),(0,a.jsxs)(`div`,{className:`relative w-full h-[350px] md:h-[450px] bg-emerald-950 flex flex-col justify-end`,children:[(0,a.jsxs)(`div`,{className:`absolute inset-0`,children:[(0,a.jsx)(`img`,{src:c,alt:`Struktur Organisasi Banner`,className:`w-full h-full object-cover opacity-60`}),(0,a.jsx)(`div`,{className:`absolute inset-0 bg-gradient-to-t from-emerald-950 via-emerald-950/40 to-transparent`})]}),(0,a.jsxs)(`div`,{className:`relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pb-12`,children:[(0,a.jsx)(`h1`,{className:`text-4xl md:text-5xl font-extrabold text-white mb-2 drop-shadow-md`,children:`Struktur Organisasi`}),(0,a.jsx)(`div`,{className:`w-20 h-1.5 bg-amber-500 rounded-sm mb-4`}),o?.deskripsi&&(0,a.jsx)(`p`,{className:`text-white/90 max-w-2xl text-lg leading-relaxed drop-shadow-md`,children:o.deskripsi})]})]}),(0,a.jsx)(i,{items:[{label:`Profil`},{label:`Struktur Organisasi`}]}),(0,a.jsx)(`div`,{className:`py-20 bg-slate-50 relative overflow-hidden min-h-screen`,children:(0,a.jsxs)(`div`,{className:`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10`,children:[(0,a.jsxs)(`div`,{className:`text-center mb-16`,children:[(0,a.jsx)(`h2`,{className:`text-3xl font-extrabold text-emerald-950 mb-4`,children:`Struktur Organisasi`}),(0,a.jsx)(`p`,{className:`text-slate-600 max-w-2xl mx-auto`,children:`Susunan pengelola Program Pascasarjana IAI Persis Bandung yang berkomitmen untuk menyelenggarakan pendidikan dan pelayanan akademik terbaik.`})]}),e&&e.length>0?(0,a.jsx)(`div`,{className:`flex flex-col items-center w-full overflow-x-auto pb-10`,children:(0,a.jsxs)(`div`,{className:`min-w-[800px] flex flex-col items-center`,children:[(0,a.jsx)(`style`,{dangerouslySetInnerHTML:{__html:`
                                    .organogram ul {
                                        padding-top: 20px;
                                        position: relative;
                                        display: flex;
                                        justify-content: center;
                                    }
                                    .organogram li {
                                        float: left;
                                        text-align: center;
                                        list-style-type: none;
                                        position: relative;
                                        padding: 20px 10px 0 10px;
                                    }
                                    .organogram li::before, .organogram li::after {
                                        content: '';
                                        position: absolute;
                                        top: 0;
                                        right: 50%;
                                        border-top: 2px solid #34d399; /* emerald-400 */
                                        width: 50%;
                                        height: 20px;
                                    }
                                    .organogram li::after {
                                        right: auto;
                                        left: 50%;
                                        border-left: 2px solid #34d399;
                                    }
                                    .organogram li:only-child::after, .organogram li:only-child::before {
                                        display: none;
                                    }
                                    .organogram li:only-child {
                                        padding-top: 0;
                                    }
                                    .organogram li:first-child::before, .organogram li:last-child::after {
                                        border: 0 none;
                                    }
                                    .organogram li:last-child::before {
                                        border-right: 2px solid #34d399;
                                        border-radius: 0 5px 0 0;
                                    }
                                    .organogram li:first-child::after {
                                        border-radius: 5px 0 0 0;
                                    }
                                    .organogram ul ul::before {
                                        content: '';
                                        position: absolute;
                                        top: 0;
                                        left: 50%;
                                        border-left: 2px solid #34d399;
                                        width: 0;
                                        height: 20px;
                                    }
                                `}}),(0,a.jsx)(`div`,{className:`organogram`,children:(0,a.jsx)(`ul`,{children:n.map(e=>(0,a.jsx)(s,{node:e},e.id))})})]})}):(0,a.jsxs)(`div`,{className:`text-center py-20 bg-white rounded-xl border border-dashed border-slate-300`,children:[(0,a.jsx)(Users,{className:`w-16 h-16 text-slate-300 mx-auto mb-4`}),(0,a.jsx)(`h3`,{className:`text-xl font-bold text-slate-700 mb-2`,children:`Struktur Belum Tersedia`}),(0,a.jsx)(`p`,{className:`text-slate-500`,children:`Data struktur organisasi saat ini belum dimasukkan ke dalam sistem.`})]})]})})]})}export{c as default};