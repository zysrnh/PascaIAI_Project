import React, { useState } from 'react';
import { Head, Link, useForm } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import Sidebar from '@/Components/Admin/Sidebar';
import PrimaryButton from '@/Components/PrimaryButton';
import InputLabel from '@/Components/InputLabel';
import TextInput from '@/Components/TextInput';
import InputError from '@/Components/InputError';
import { Save, ArrowLeft, Image as ImageIcon, Trash2 } from 'lucide-react';

export default function Form({ auth, anggota, defaultUrutan = 0, defaultParentId = null }) {
    const isEdit = !!anggota;
    const [isLoaded] = useState(true);

    const { data, setData, post, processing, errors } = useForm({
        nama: anggota?.nama || '',
        jabatan: anggota?.jabatan || '',
        urutan: anggota?.urutan || defaultUrutan,
        parent_id: anggota?.parent_id || defaultParentId,
        foto: null,
        delete_foto: false,
    });

    const submit = (e) => {
        e.preventDefault();
        const targetRoute = isEdit 
            ? route('admin.profil.struktur-organisasi.update', anggota.id)
            : route('admin.profil.struktur-organisasi.store');
            
        post(targetRoute, {
            forceFormData: true
        });
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="text-xl font-semibold leading-tight text-white">Manajemen Profil: Struktur Organisasi</h2>}
        >
            <Head title={isEdit ? "Edit Anggota" : "Tambah Anggota"} />

            <div className="flex bg-slate-50 min-h-screen">
                <Sidebar />

                <div className={`min-w-0 flex-1 transition-all duration-700 ease-out transform ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
                    <div className="py-8 px-4 sm:px-6 lg:px-8">
                        <div className="mb-6 flex items-center gap-4">
                            <Link href={route('admin.profil.struktur-organisasi.index')} className="p-2 bg-white rounded-full shadow-sm hover:bg-slate-100 transition-colors">
                                <ArrowLeft className="w-5 h-5 text-slate-600" />
                            </Link>
                            <div>
                                <h1 className="text-2xl font-bold text-slate-800">{isEdit ? 'Edit Anggota Struktur' : 'Tambah Anggota Struktur'}</h1>
                                <p className="text-sm text-slate-500">Isi detail data pengurus organisasi.</p>
                            </div>
                        </div>

                        <div className="bg-white rounded-[5px] shadow-sm border border-slate-200 p-6 sm:p-8 max-w-3xl">
                            <form onSubmit={submit} className="space-y-6">
                                <div>
                                    <InputLabel htmlFor="nama" value="Nama Lengkap (beserta gelar)" className="font-bold text-slate-700 mb-1" />
                                    <TextInput
                                        id="nama"
                                        type="text"
                                        className="mt-1 block w-full"
                                        value={data.nama}
                                        onChange={(e) => setData('nama', e.target.value)}
                                        required
                                        placeholder="Contoh: Dr. H. Fulan, M.Ag."
                                    />
                                    <InputError message={errors.nama} className="mt-2" />
                                </div>

                                <div>
                                    <InputLabel htmlFor="jabatan" value="Jabatan" className="font-bold text-slate-700 mb-1" />
                                    <TextInput
                                        id="jabatan"
                                        type="text"
                                        className="mt-1 block w-full"
                                        value={data.jabatan}
                                        onChange={(e) => setData('jabatan', e.target.value)}
                                        required
                                        placeholder="Contoh: Direktur Pascasarjana"
                                    />
                                    <InputError message={errors.jabatan} className="mt-2" />
                                </div>

                                <div className="hidden">
                                    <InputLabel htmlFor="urutan" value="Level/Urutan Tampil" className="font-bold text-slate-700 mb-1" />
                                    <TextInput
                                        id="urutan"
                                        type="text"
                                        className="mt-1 block w-full md:w-1/3"
                                        value={data.urutan}
                                        onChange={(e) => setData('urutan', e.target.value)}
                                        required
                                    />
                                    <p className="text-xs text-slate-500 mt-1">Contoh: 1, 2A, 2B, 3A, dll.</p>
                                    <InputError message={errors.urutan} className="mt-2" />
                                </div>

                                <div>
                                    <InputLabel htmlFor="foto" value="Foto Profil" className="font-bold text-slate-700 mb-2" />
                                    
                                    {isEdit && anggota?.foto && !data.foto && !data.delete_foto && (
                                        <div className="mb-4">
                                            <p className="text-sm text-slate-500 mb-2">Foto saat ini:</p>
                                            <div className="flex items-start gap-4">
                                                <img src={anggota.foto} alt="Foto" className="w-32 h-32 object-cover rounded-md border border-slate-200" />
                                                <button
                                                    type="button"
                                                    onClick={() => setData('delete_foto', true)}
                                                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-[5px] transition-colors"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                    Hapus Foto
                                                </button>
                                            </div>
                                        </div>
                                    )}

                                    {data.delete_foto && !data.foto && (
                                        <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-[5px]">
                                            <p className="text-sm text-amber-700 font-medium">Foto saat ini akan dihapus saat disimpan.</p>
                                            <button
                                                type="button"
                                                onClick={() => setData('delete_foto', false)}
                                                className="text-sm text-amber-600 hover:text-amber-800 underline mt-1"
                                            >
                                                Batal Hapus
                                            </button>
                                        </div>
                                    )}

                                    {data.foto && (
                                        <div className="mb-4">
                                            <p className="text-sm text-emerald-600 mb-2 font-medium">Preview foto baru:</p>
                                            <img src={URL.createObjectURL(data.foto)} alt="Preview" className="w-32 h-32 object-cover rounded-md border-2 border-emerald-500 shadow-sm" />
                                        </div>
                                    )}

                                    <div className="flex items-center gap-4">
                                        <label className="flex items-center justify-center w-full md:w-2/3 px-4 py-3 bg-slate-50 border-2 border-dashed border-slate-300 rounded-[5px] cursor-pointer hover:bg-slate-100 hover:border-emerald-500 transition-colors group">
                                            <div className="flex flex-col items-center">
                                                <ImageIcon className="w-6 h-6 text-slate-400 group-hover:text-emerald-500 mb-1" />
                                                <span className="text-sm text-slate-500 group-hover:text-emerald-600">Klik untuk unggah foto (Opsional)</span>
                                                <span className="text-xs text-slate-400 mt-1">JPG, PNG, WEBP (Max 2MB, Rasio 1:1 disarankan)</span>
                                            </div>
                                            <input
                                                type="file"
                                                id="foto"
                                                className="hidden"
                                                onChange={(e) => setData('foto', e.target.files[0])}
                                                accept="image/*"
                                            />
                                        </label>
                                    </div>
                                    <InputError message={errors.foto} className="mt-2" />
                                </div>

                                <div className="pt-6 border-t border-slate-200 flex justify-end gap-3">
                                    <Link href={route('admin.profil.struktur-organisasi.index')}>
                                        <button type="button" className="px-4 py-2 bg-white border border-slate-300 rounded-[5px] text-slate-700 hover:bg-slate-50 font-medium">
                                            Batal
                                        </button>
                                    </Link>
                                    <PrimaryButton className="bg-emerald-600 hover:bg-emerald-700 gap-2" disabled={processing}>
                                        <Save className="w-4 h-4" />
                                        {isEdit ? 'Simpan Perubahan' : 'Tambah Anggota'}
                                    </PrimaryButton>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
